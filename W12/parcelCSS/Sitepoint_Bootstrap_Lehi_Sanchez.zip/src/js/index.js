import $ from "jquery";
import popper from 'popper.js';
import bootstrap from 'bootstrap';
import '@fortawesome/fontawesome-free/css/all.css'
